package hust.soict.dsai.aims.playable;

public interface Playable {
	public void play();
	
}
